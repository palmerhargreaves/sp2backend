#!/bin/bash

docker exec -i -t aero.admin /bin/bash