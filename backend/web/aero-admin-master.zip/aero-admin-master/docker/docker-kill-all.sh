#!/bin/bash

docker rm --force `docker ps -qa`