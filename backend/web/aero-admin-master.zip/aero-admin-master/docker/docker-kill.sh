#!/bin/bash

docker rm --force aero.admin